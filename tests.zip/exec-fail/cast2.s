	.text
my_malloc:
	pushq %rbp
	movq %rsp, %rbp
	call malloc
	leave
	ret
my_error:
	pushq %rbp
	movq %rsp, %rbp
	call puts
	movq $1, %rdi
	call exit
	leave
	ret
my_string_concat:
	pushq %rbp
	movq %rsp, %rbp
	cmpq $0, %rdi
	jne first_not_null_0
	movq %rsi, %rax
	leave
	ret
first_not_null_0:
	cmpq $0, %rsi
	jne second_not_null_1
	movq %rdi, %rax
	leave
	ret
second_not_null_1:
	pushq %rdi
	pushq %rsi
	movq 8(%rdi), %rdi
	call strlen
	movq %rax, %r12
	popq %rdi
	movq 8(%rdi), %rdi
	call strlen
	movq %rax, %r13
	movq %r12, %rdi
	addq %r13, %rdi
	incq %rdi
	call malloc
	movq %rax, %r14
	popq %rdi
	movq 8(%rdi), %rsi
	movq %r14, %rdi
	call strcpy
	popq %rdi
	movq 8(%rdi), %rsi
	movq %r14, %rdi
	addq %r12, %rdi
	call strcpy
	movq $16, %rdi
	call malloc
	movq $class_String, (%rax)
	movq %r14, 8(%rax)
	leave
	ret
A_A:
	pushq %rbp
	pushq %r12
	movq %rsp, %rbp
	movq $8, %rdi
	call my_malloc
	cmpq $0, %rax
	jne alloc_ok_2
	movq $error_msg_3, %rdi
	call my_error
alloc_ok_2:
	movq $class_A, (%rax)
	movq %rax, %r12
	movq %r12, %rax
	movq %rbp, %rsp
	popq %r12
	popq %rbp
	ret
B_B:
	pushq %rbp
	pushq %r12
	movq %rsp, %rbp
	movq $8, %rdi
	call my_malloc
	cmpq $0, %rax
	jne alloc_ok_4
	movq $error_msg_5, %rdi
	call my_error
alloc_ok_4:
	movq $class_B, (%rax)
	movq %rax, %r12
	movq %r12, %rdi
	call A_A
	movq %r12, %rax
	movq %rbp, %rsp
	popq %r12
	popq %rbp
	ret
C_C:
	pushq %rbp
	pushq %r12
	movq %rsp, %rbp
	movq $8, %rdi
	call my_malloc
	cmpq $0, %rax
	jne alloc_ok_6
	movq $error_msg_7, %rdi
	call my_error
alloc_ok_6:
	movq $class_C, (%rax)
	movq %rax, %r12
	movq %r12, %rdi
	call B_B
	movq %r12, %rax
	movq %rbp, %rsp
	popq %r12
	popq %rbp
	ret
Main_main:
	pushq %rbp
	movq %rsp, %rbp
	subq $8, %rsp
	popq %rax
	movq %rax, -8(%rbp)
	leave
	ret
Main_Main:
	pushq %rbp
	pushq %r12
	movq %rsp, %rbp
	movq $8, %rdi
	call my_malloc
	cmpq $0, %rax
	jne alloc_ok_8
	movq $error_msg_9, %rdi
	call my_error
alloc_ok_8:
	movq $class_Main, (%rax)
	movq %rax, %r12
	movq %r12, %rax
	movq %rbp, %rsp
	popq %r12
	popq %rbp
	ret
	.globl main
main:
	pushq %rbp
	movq %rsp, %rbp
	call Main_main
	movq $0, %rax
	leave
	ret
	.data
class_A:
	.quad class_Object
class_B:
	.quad class_A
class_C:
	.quad class_B
class_Main:
	.quad class_Object
	.quad Main_main
class_String:
	.quad class_Object
class_Object:
	.quad 0
error_msg_3:
	.string "memory allocation failed"
error_msg_5:
	.string "memory allocation failed"
error_msg_7:
	.string "memory allocation failed"
error_msg_9:
	.string "memory allocation failed"
