	.text
my_malloc:
	pushq %rbp
	movq %rsp, %rbp
	call malloc
	leave
	ret
my_error:
	pushq %rbp
	movq %rsp, %rbp
	call puts
	movq $1, %rdi
	call exit
	leave
	ret
my_string_concat:
	pushq %rbp
	movq %rsp, %rbp
	cmpq $0, %rdi
	jne first_not_null_0
	movq %rsi, %rax
	leave
	ret
first_not_null_0:
	cmpq $0, %rsi
	jne second_not_null_1
	movq %rdi, %rax
	leave
	ret
second_not_null_1:
	pushq %rdi
	pushq %rsi
	movq 8(%rdi), %rdi
	call strlen
	movq %rax, %r12
	popq %rdi
	movq 8(%rdi), %rdi
	call strlen
	movq %rax, %r13
	movq %r12, %rdi
	addq %r13, %rdi
	incq %rdi
	call malloc
	movq %rax, %r14
	popq %rdi
	movq 8(%rdi), %rsi
	movq %r14, %rdi
	call strcpy
	popq %rdi
	movq 8(%rdi), %rsi
	movq %r14, %rdi
	addq %r12, %rdi
	call strcpy
	movq $16, %rdi
	call malloc
	movq $class_String, (%rax)
	movq %r14, 8(%rax)
	leave
	ret
A_A:
	pushq %rbp
	pushq %r12
	movq %rsp, %rbp
	movq $16, %rdi
	call my_malloc
	cmpq $0, %rax
	jne alloc_ok_2
	movq $error_msg_3, %rdi
	call my_error
alloc_ok_2:
	movq $class_A, (%rax)
	movq %rax, %r12
	movq $0, 8(%r12)
	movq %r12, %rax
	movq %rbp, %rsp
	popq %r12
	popq %rbp
	ret
Main_main:
	pushq %rbp
	movq %rsp, %rbp
	subq $8, %rsp
	pushq $0
	popq %rax
	movq %rax, -8(%rbp)
	movq 16(%rbp), %rax
	pushq %rax
	movq -8(%rbp), %rax
	pushq %rax
	popq %rax
	cmpq $0, %rax
	jne non_null_4
	movq $error_msg_5, %rdi
	call my_error
non_null_4:
	movq (%rax), %rcx
	movq -8(%rax), %rax
	pushq %rax
	movq $error_msg_6, %rdi
	call my_error
	addq $8, %rsp
	leave
	ret
Main_Main:
	pushq %rbp
	pushq %r12
	movq %rsp, %rbp
	movq $8, %rdi
	call my_malloc
	cmpq $0, %rax
	jne alloc_ok_7
	movq $error_msg_8, %rdi
	call my_error
alloc_ok_7:
	movq $class_Main, (%rax)
	movq %rax, %r12
	movq %r12, %rax
	movq %rbp, %rsp
	popq %r12
	popq %rbp
	ret
	.globl main
main:
	pushq %rbp
	movq %rsp, %rbp
	call Main_main
	movq $0, %rax
	leave
	ret
	.data
class_A:
	.quad class_Object
class_Main:
	.quad class_Object
	.quad Main_main
class_String:
	.quad class_Object
class_Object:
	.quad 0
error_msg_3:
	.string "memory allocation failed"
error_msg_5:
	.string "null pointer exception"
error_msg_6:
	.string "Method not found: System.out.print"
error_msg_8:
	.string "memory allocation failed"
