	.text
my_malloc:
	pushq %rbp
	movq %rsp, %rbp
	call malloc
	leave
	ret
my_error:
	pushq %rbp
	movq %rsp, %rbp
	call puts
	movq $1, %rdi
	call exit
	leave
	ret
my_string_concat:
	pushq %rbp
	movq %rsp, %rbp
	cmpq $0, %rdi
	jne first_not_null_0
	movq %rsi, %rax
	leave
	ret
first_not_null_0:
	cmpq $0, %rsi
	jne second_not_null_1
	movq %rdi, %rax
	leave
	ret
second_not_null_1:
	pushq %rdi
	pushq %rsi
	movq 8(%rdi), %rdi
	call strlen
	movq %rax, %r12
	popq %rdi
	movq 8(%rdi), %rdi
	call strlen
	movq %rax, %r13
	movq %r12, %rdi
	addq %r13, %rdi
	incq %rdi
	call malloc
	movq %rax, %r14
	popq %rdi
	movq 8(%rdi), %rsi
	movq %r14, %rdi
	call strcpy
	popq %rdi
	movq 8(%rdi), %rsi
	movq %r14, %rdi
	addq %r12, %rdi
	call strcpy
	movq $16, %rdi
	call malloc
	movq $class_String, (%rax)
	movq %r14, 8(%rax)
	leave
	ret
Main_main:
	pushq %rbp
	movq %rsp, %rbp
	subq $24, %rsp
	pushq $0
	popq %rax
	movq %rax, -8(%rbp)
	pushq $0
	popq %rax
	movq %rax, -16(%rbp)
	jmp for_start_2
for_start_2:
	movq -8(%rbp), %rax
	pushq %rax
	pushq $10
	popq %rbx
	popq %rax
	cmpq %rbx, %rax
	setl %al
	movzbq %al, %rax
	pushq %rax
	popq %rax
	cmpq $0, %rax
	je for_end_5
	jmp for_body_3
for_body_3:
	jmp for_update_4
for_update_4:
	pushq $0
	popq %rax
	movq %rax, -24(%rbp)
	pushq $10
	popq %rax
	movq %rax, -24(%rbp)
	pushq %rax
	addq $8, %rsp
	jmp for_start_6
for_start_6:
	movq -24(%rbp), %rax
	pushq %rax
	pushq $0
	popq %rbx
	popq %rax
	cmpq %rbx, %rax
	setg %al
	movzbq %al, %rax
	pushq %rax
	popq %rax
	cmpq $0, %rax
	je for_end_9
	jmp for_body_7
for_body_7:
	jmp for_update_8
for_update_8:
	movq -16(%rbp), %rax
	pushq %rax
	pushq $1
	popq %rbx
	popq %rax
	addq %rbx, %rax
	pushq %rax
	popq %rax
	movq %rax, -16(%rbp)
	pushq %rax
	addq $8, %rsp
	movq -24(%rbp), %rax
	pushq %rax
	pushq $1
	popq %rbx
	popq %rax
	subq %rbx, %rax
	pushq %rax
	popq %rax
	movq %rax, -24(%rbp)
	pushq %rax
	addq $8, %rsp
	jmp for_start_6
for_end_9:
	movq -8(%rbp), %rax
	pushq %rax
	pushq $1
	popq %rbx
	popq %rax
	addq %rbx, %rax
	pushq %rax
	popq %rax
	movq %rax, -8(%rbp)
	pushq %rax
	addq $8, %rsp
	jmp for_start_2
for_end_5:
	movq -16(%rbp), %rax
	pushq %rax
	pushq $100
	popq %rbx
	popq %rax
	cmpq %rbx, %rax
	sete %al
	movzbq %al, %rax
	pushq %rax
	popq %rax
	cmpq $0, %rax
	je else_10
	movq 16(%rbp), %rax
	pushq %rax
	movq $16, %rdi
	call my_malloc
	movq $class_String, (%rax)
	movq $str_12, 8(%rax)
	pushq %rax
	movq $error_msg_13, %rdi
	call my_error
	addq $8, %rsp
	jmp endif_11
else_10:
endif_11:
	leave
	ret
Main_Main:
	pushq %rbp
	pushq %r12
	movq %rsp, %rbp
	movq $8, %rdi
	call my_malloc
	cmpq $0, %rax
	jne alloc_ok_14
	movq $error_msg_15, %rdi
	call my_error
alloc_ok_14:
	movq $class_Main, (%rax)
	movq %rax, %r12
	movq %r12, %rax
	movq %rbp, %rsp
	popq %r12
	popq %rbp
	ret
	.globl main
main:
	pushq %rbp
	movq %rsp, %rbp
	call Main_main
	movq $0, %rax
	leave
	ret
	.data
class_Main:
	.quad class_Object
	.quad Main_main
class_String:
	.quad class_Object
class_Object:
	.quad 0
str_12:
	.string "ok\n"
error_msg_13:
	.string "Method not found: System.out.print"
error_msg_15:
	.string "memory allocation failed"
