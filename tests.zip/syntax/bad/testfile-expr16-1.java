class A { void m() { int x = (A.x)0; } }
class Main { public static void main(String args[]) { } }
