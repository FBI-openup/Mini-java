package java.lang.*;
class A { }
class Main { public static void main(String args[]) { } }
