class A { void m() { }
class Main { public static void main(String args[]) { } }
