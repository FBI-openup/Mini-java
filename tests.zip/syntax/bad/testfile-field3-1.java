class A { int x }
class Main { public static void main(String args[]) { } }
