class A { A() { }
class Main { public static void main(String args[]) { } }
