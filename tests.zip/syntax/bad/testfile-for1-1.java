class A { void m() { int i; for( ; ; true; i=i+1) ; } }
class Main { public static void main(String args[]) { } }
