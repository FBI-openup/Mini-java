class int { }
class Main { public static void main(String args[]) { } }
