class A { int; }
class Main { public static void main(String args[]) { } }
