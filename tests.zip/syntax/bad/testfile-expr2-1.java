class A { A a; void m() { int x = a.; } }
class Main { public static void main(String args[]) { } }
