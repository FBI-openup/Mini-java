class A extendsa B { }
class Main { public static void main(String args[]) { } }
