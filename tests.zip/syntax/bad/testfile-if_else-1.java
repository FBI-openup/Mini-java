class A { void m() { if (true) ; else } }
class Main { public static void main(String args[]) { } }
