class A { void m() { int i; for( i = 0, ; true; i=i+1) ; } }
class Main { public static void main(String args[]) { } }
