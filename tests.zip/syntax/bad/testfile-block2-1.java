class A { int m() { { 0 } } }
class Main { public static void main(String args[]) { } }
