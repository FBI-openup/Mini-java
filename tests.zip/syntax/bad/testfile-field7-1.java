class A {
    int * j;
}
class Main { public static void main(String args[]) { } }
