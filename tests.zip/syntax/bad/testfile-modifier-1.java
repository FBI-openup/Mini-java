class A { stati int x; }
class Main { public static void main(String args[]) { } }
