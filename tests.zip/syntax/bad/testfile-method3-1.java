class A {
    int i;
    int meth {return 0;}}
class Main { public static void main(String args[]) { } }
