class A {
    String s = " " ";
}
class Main { public static void main(String args[]) { } }
