class A extends A {}
class Main { public static void main(String args[]) { } }
