class A { void m(int x) { int x; } }
class Main { public static void main(String args[]) { } }
