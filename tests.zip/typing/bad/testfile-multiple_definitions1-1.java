class A { A() { } A() { } }
class Main { public static void main(String args[]) { } }
