class A { void m() { } int m() { } }
class Main { public static void main(String args[]) { } }
