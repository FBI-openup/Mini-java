class A {
    int f() {
	for(; false;)
	    return 0;
    }
}
class Main { public static void main(String args[]) { } }
