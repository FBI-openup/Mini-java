class Object {}
class Main { public static void main(String args[]) { } }
