class A {void m() {  boolean b = true == 1; } }
class Main { public static void main(String args[]) { } }
