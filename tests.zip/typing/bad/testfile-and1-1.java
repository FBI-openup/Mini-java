class A { void m() { boolean x = 1 && true; } }
class Main { public static void main(String args[]) { } }
