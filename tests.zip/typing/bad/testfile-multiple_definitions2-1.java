class A { void m() { } void m() { } }
class Main { public static void main(String args[]) { } }
