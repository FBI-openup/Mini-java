class A { void m() { boolean b = null <= 1; } }
class Main { public static void main(String args[]) { } }
