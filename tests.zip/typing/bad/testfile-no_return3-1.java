class A {
    int f() {
	if (true) ; else return 0;
    }
}
class Main { public static void main(String args[]) { } }
