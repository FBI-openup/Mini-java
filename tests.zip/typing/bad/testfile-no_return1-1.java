class A { int m() { } }
class Main { public static void main(String args[]) { } }
