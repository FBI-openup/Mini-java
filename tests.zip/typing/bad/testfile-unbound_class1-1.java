class A extends B {}
class Main { public static void main(String args[]) { } }
