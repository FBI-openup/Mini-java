class A { B() { } }

class Main { public static void main(String args[]) { } }
