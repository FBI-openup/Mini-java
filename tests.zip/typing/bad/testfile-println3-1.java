class M { int m() { return System.out.println(""); } }

class Main { public static void main(String args[]) { } }
