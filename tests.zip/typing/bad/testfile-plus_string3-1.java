class M { void m() { int s = 1 + ""; } }
class Main { public static void main(String args[]) { } }
